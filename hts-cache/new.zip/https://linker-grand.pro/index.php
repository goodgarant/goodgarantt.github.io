<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<title>Linker-grand.pro - Сервис безопасных сделок в интернете. - Linker-grand.pro</title> 
<meta name="description" content="Linker-grand.pro" />

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="generator" content="Cotonti http://www.cotonti.com" />
<link rel="canonical" href="https://linker-grand.pro/" />
<base href="https://linker-grand.pro/" />
<link href="themes/bootlance/bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="themes/bootlance/bootstrap/css/bootstrap-responsive.css" type="text/css" rel="stylesheet" />
<link href="themes/bootlance/css/modalbox.css" type="text/css" rel="stylesheet" />
<link href="themes/bootlance/css/style.css" type="text/css" rel="stylesheet" />
<link href="themes/bootlance/css/fix.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jqModal.min.js"></script>
<script type="text/javascript" src="js/base.js"></script>
<script type="text/javascript" src="js/ajax_on.js"></script>
<script type="text/javascript" src="plugins/search/js/hl.min.js"></script>
<script type="text/javascript" src="plugins/locationselector/js/locationselector.js"></script>
<script type="text/javascript" src="themes/bootlance/js/js.js"></script>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="apple-touch-icon" href="apple-touch-icon.png" />
</head>

<body>

	<div id="AuthModal" class="modal hide fade">
		<div class="modal-header">
			<h3 id="myModalLabel">Вход</h3>
			</div>
			<div class="modal-body">
				<form class="form-horizontal" action="login.php?a=check&amp;redirect=aW5kZXgucGhw" method="post"><div style="display:inline;margin:0;padding:0"><input type="hidden" name="x" value="10648D95" /></div>
					<div class="control-group">
						<label class="control-label" for="inputEmail">Имя или email</label>
						<div class="controls">
							<input type="text" name="rusername" id="inputEmail" />
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="inputPassword">Пароль</label>
						<div class="controls">
							<input type="password" name="rpassword" id="inputPassword" /><br/>
							<a rel="nofollow" class="link small" href="index.php?e=users&amp;m=passrecover">Восстановить пароль</a>
						</div>
					</div>
					<div class="control-group">
						<div class="controls">
							<label class="checkbox">
							<input type="checkbox" name="rremember" /> Запомнить меня
							</label><br/>
							<button type="submit" class="btn btn-primary btn-large">Вход</button>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true">Закрыть</button>
		</div>
	</div>	
	<div id="wrapper" class="container">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-inner">
				<div class="container">
						<ul class="nav pull-right">
							<li><a href="login.php" data-toggle="modal" onClick="$('#AuthModal').modal(); return false;">Вход</a></li>
							<li><a href="index.php?e=users&amp;m=register">Зарегистрироваться</a></li>
													</ul>
				</div>
			</div>
		</div>
							
		<div id="header" class="row">
			<div class="span4">
				<div class="logo"><a href="index.php" title="Linker-grand.pro - Сервис безопасных сделок в интернете. / Linker-grand.pro"><img src="themes/bootlance/img/logo.png"/></a></div>
			</div>
			<div class="span5">
				
			</div>
			<div class="span3 textright paddingtop10">
			</div>
		</div>

		<div class="navbar">
			<div class="navbar-inner">
				<ul class="nav">
					<li><a href="index.php"><b>Главная</b></a></li>
					
                <li><a href="index.php?e=sbr"><b>Мои сделки</b></a></li>
           <li> <a href="index.php?e=sbr&amp;m=add"><b>Предложить сделку</b></a></li>
				</ul>
			</div>
		</div>
		
		<div id="main" class="content"><div class="row">
	<div class="span12">
		<div class="row">
	<div class="span3">
		<div class="row">
			<div class="span1">
				<img src="datas/avatars/15-7p7evwgy2dq.jpg" alt="" class="userimg avatar" />
			</div>
			<div class="span2">
				<p><a href="index.php?e=users&amp;m=details&amp;id=15&amp;u=hiwoo">hiwoo</a></p>
				<p>
					<span class="label label-info">106.0</span>
					<span style="margin-top: 5px;" class="label label-success">Рекомендован</span>
				</p>
			</div>
		</div>
		<br/>
	</div>
	<div class="span3">
		<div class="row">
			<div class="span1">
				<img src="datas/avatars/8-kutuzov1.jpg" alt="" class="userimg avatar" />
			</div>
			<div class="span2">
				<p><a href="index.php?e=users&amp;m=details&amp;id=8&amp;u=Kutuzow99">Kutuzow99</a></p>
				<p>
					<span class="label label-important">PRO</span> 
					<span class="label label-info">876.0</span>
					<span style="margin-top: 5px;" class="label label-success">Рекомендован</span>
				</p>
			</div>
		</div>
		<br/>
	</div>
	<div class="span3">
		<div class="row">
			<div class="span1">
				<img src="datas/avatars/6-ozzy-osbourne-london-1991-billboard-1548-650.jpg" alt="" class="userimg avatar" />
			</div>
			<div class="span2">
				<p><a href="index.php?e=users&amp;m=details&amp;id=6&amp;u=Ozzy">Ozzy</a></p>
				<p>
					<span class="label label-important">PRO</span> 
					<span class="label label-info">1 315.2</span>
					<span style="margin-top: 5px;" class="label label-success">Рекомендован</span>
				</p>
			</div>
		</div>
		<br/>
	</div>
	<div class="span3">
		<div class="row">
			<div class="span1">
				<img src="datas/avatars/5-caligrafia-portada.png" alt="" class="userimg avatar" />
			</div>
			<div class="span2">
				<p><a href="index.php?e=users&amp;m=details&amp;id=5&amp;u=%D0%A1ocaColaFoks">СocaColaFoks</a></p>
				<p>
					<span class="label label-important">PRO</span> 
					<span class="label label-info">1 729.2</span>
					<span style="margin-top: 5px;" class="label label-success">Рекомендован</span>
				</p>
			</div>
		</div>
		<br/>
	</div>
	</div>	
<div class="pull-right"><a href="index.php?e=paytop&amp;area=top">Как сюда попасть?</a></div>
<hr/>
	</div>
</div>
		
	
	<div class="promo-description">
  Linker-grand — автоматический сервис безопасных сделок, разработанный командой pwLVL при технической поддержке L2on.
  За годы работы мы накопили большой багаж знаний и опыта.
  Linker-grand является универсальным гарантом сделок в онлайн-играх, фрилансе, а также в любых других дистанционных
  продажах товаров и услуг, и надежно обеспечивает безопасность как покупателям, так и продавцам.

  <ul class="icons list-inline">
    <li>
      <div class="icon home"></div>
      Сервис несет ответственность<br>за разрешение споров
    </li><li>
      <div class="icon date"></div>
      Работает 24 часа в сутки,<br>7 дней в неделю
    </li><li>
      <div class="icon calc"></div>
      Комиссия менее 5%
    </li>
  </ul>
</div>

<ul class="promo-systems list-inline">
  <li class="yandex"></li>
  <li class="qiwi"></li>
  <li class="webmoney"></li>
</ul>

<div class="row">
<div class="span3 topsis">
		<h4 class="mboxHD">Топ - Исполнителей</h4>
			<div class="row">
		<div class="span1">
			<img src="datas/avatars/3-letter-1347393_960_720.jpg" alt="" class="userimg avatar" />
		</div>
		<div class="span2">
			<p><a href="index.php?e=users&amp;m=details&amp;id=3&amp;u=FicusFox">FicusFox</a></p>
			<p>
				<span class="label label-important">PRO</span> 
				<span class="label label-info">2 221.4</span>
			</p>
		</div>
	</div>
	<br/>		
	<div class="row">
		<div class="span1">
			<img src="datas/avatars/5-caligrafia-portada.png" alt="" class="userimg avatar" />
		</div>
		<div class="span2">
			<p><a href="index.php?e=users&amp;m=details&amp;id=5&amp;u=%D0%A1ocaColaFoks">СocaColaFoks</a></p>
			<p>
				<span class="label label-important">PRO</span> 
				<span class="label label-info">1 729.2</span>
			</p>
		</div>
	</div>
	<br/>		
	<div class="row">
		<div class="span1">
			<img src="datas/avatars/6-ozzy-osbourne-london-1991-billboard-1548-650.jpg" alt="" class="userimg avatar" />
		</div>
		<div class="span2">
			<p><a href="index.php?e=users&amp;m=details&amp;id=6&amp;u=Ozzy">Ozzy</a></p>
			<p>
				<span class="label label-important">PRO</span> 
				<span class="label label-info">1 315.2</span>
			</p>
		</div>
	</div>
	<br/>		
	<div class="row">
		<div class="span1">
			<img src="datas/avatars/8-kutuzov1.jpg" alt="" class="userimg avatar" />
		</div>
		<div class="span2">
			<p><a href="index.php?e=users&amp;m=details&amp;id=8&amp;u=Kutuzow99">Kutuzow99</a></p>
			<p>
				<span class="label label-important">PRO</span> 
				<span class="label label-info">876.0</span>
			</p>
		</div>
	</div>
	<br/>		

		<br/>
		<br/>
		<h4 class="mboxHD">Топ - Заказчиков</h4>
			<div class="row">
		<div class="span1">
			<img src="datas/avatars/7-768px-xiaomi_logo.svg.png" alt="" class="userimg avatar" />
		</div>
		<div class="span2">
			<p><a href="index.php?e=users&amp;m=details&amp;id=7&amp;u=XiaomiMi">XiaomiMi</a></p>
			<p>
				<span class="label label-important">PRO</span> 
				<span class="label label-info">1 051.2</span>
			</p>
		</div>
	</div>
	<br/>		
	<div class="row">
		<div class="span1">
			<img src="plugins/genderavatar/img/u.png" alt="Аватар" class="avatar img-responsive" />
		</div>
		<div class="span2">
			<p><a href="index.php?e=users&amp;m=details&amp;id=9&amp;u=Osipov">Osipov</a></p>
			<p>
				<span class="label label-important">PRO</span> 
				<span class="label label-info">591.0</span>
			</p>
		</div>
	</div>
	<br/>		
	<div class="row">
		<div class="span1">
			<img src="datas/avatars/10-crazy-frog-1100.jpg" alt="" class="userimg avatar" />
		</div>
		<div class="span2">
			<p><a href="index.php?e=users&amp;m=details&amp;id=10&amp;u=CrazzyzGo">CrazzyzGo</a></p>
			<p>
				<span class="label label-important">PRO</span> 
				<span class="label label-info">421.0</span>
			</p>
		</div>
	</div>
	<br/>		
	<div class="row">
		<div class="span1">
			<img src="datas/avatars/11-fosters.png" alt="" class="userimg avatar" />
		</div>
		<div class="span2">
			<p><a href="index.php?e=users&amp;m=details&amp;id=11&amp;u=Fosters">Fosters</a></p>
			<p>
				<span class="label label-important">PRO</span> 
				<span class="label label-info">351.0</span>
			</p>
		</div>
	</div>
	<br/>		
	
</div>
<div class="steps">
    <h3><span>Как это работает</span></h3>
    <ul class="list-unstyled">
      <li>
        <h4><span class="icon step1"></span>Регистрация</h4>
        Услуги гаранта сделок предоставляются только после того, как оба
        участника <a href="https://linker-grand.pro/index.php?e=users&m=register">зарегистрируются</a> на сайте.
      </li>
      <li>
        <h4><span class="icon step2"></span>Обсуждение условий</h4>
        Участники обсуждают характеристики товара и сумму оплаты, выбирают платежную систему (Яндекс.Деньги, QIWI, WebMoney или Банковская карта),
        принимают решение о сумме залога либо его отсутствии.
      </li>
      <li>
        <h4><span class="icon step3"></span>Открытие сделки</h4>
        Один из участников <a href="index.php?e=sbr&amp;m=add">открывает сделку</a>, другой её принимает.
        Если установлена опция залога, то оба участника вносят залог.
        Если на данном этапе что-то идёт не так (второй участник пропал или не внёс залог), то сделка отменяется, залоги возвращаются.
        Для общения и передачи информации используется внутренний чат.
      </li>
      <li>
        <h4><span class="icon step4"></span>Исполнение обязательств</h4>
        Покупатель вносит деньги на баланс сделки, залоги сразу же блокируются.
        Продавец видит это и передаёт товар, после чего покупатель выводит деньги с баланса на кошелек продавца.
        Продавец может отказаться от сделки и вернуть деньги покупателю.
        Суть в том, что участники могут выводить деньги с баланса только на кошельки друг друга, но не на свои.
        В случае спора участники могут обратиться к гаранту сделок (арбитраж).
      </li>
      <li>
        <h4><span class="icon step5"></span>Закрытие сделки</h4>
        Если на балансе сделки нет денег, то один из участников её закрывает, залоги возвращаются. Сделка через гаранта завершена.
      </li>
    </ul>
  </div>
  <div class="page">
<h2 class="page-header">Арбитраж Linker-grand</h2>
<p><b>Арбитраж несет материальную ответственность за разрешение споров в системе Linker-grand в размере, двукратно превышающим сумму сделки. Таким образом, в случае какой-либо ошибки в разрешении спора, сервис обязуется компенсировать все убытки (как прямые, так и косвенные).</b></p>
<h4><br>В каком случае требуется участие арбитража?</h4>
<p>Участие арбитража может потребоваться в том случае, если участники сделки не могут разрешить спор самостоятельно, при этом баланс сделки должен быть отличен от нуля. В компетенцию арбитража входит вынесение решения о распределении средств сделки между её участниками.</p>
<h4><br>Каким образом обратиться в арбитраж?</h4>
<p>Любой из участников сделки может направить соответствующее обращение консультанту в правом нижнем углу сайта либо на почту support@linker-grand.pro.
Разбирательство начинается в <b>чате сделки</b> в течение 5 рабочих дней с момента обращения.</p>
<h4><br>Как происходит разрешение споров в арбитраже?</h4>
<p>В случаи эсли сумма сделки более 15 000 rub, разрешение спора начинается с прохождения процедуры идентификации. Арбитраж устанавливает паспортные данные участников (посредством отправки на почту support@Linker-grand.pro соответствующих отсканированных документов и фотографий на фоне сайта Linker-grand).</p>
<p><b>В том случае, если какая-либо из сторон, участвующих в сделке, уклоняется от идентификации или проведения разбирательства по существу, арбитраж оставляет за собой право разрешить спор в пользу противоположной стороны.</b></p>
<p>Арбитраж проводит обязательные консультации с участниками сделки в чате сделки (или используя иные формы связи), а также устанавливает факты, достоверно свидетельствующие о выполнении или невыполнении условий сделки.</p></div>
  
  
  
</div>
<div class="about">
    <strong>Самый надежный гарант игровых сделок.</strong> За время работы мы накопили знания, опыт и составили большую базу данных как самих мошенников, так и различных видов интернет-мошенничества.
<br><br>
  <strong>Круглосуточная онлайн-поддержка.</strong> Безопасные сделки идут через специальный чат, к которому имеют доступ обе стороны, а также консультанты Linker-grand, которых можно привлечь при необходимости.
<br><br>
  <strong>Нет материальных рисков.</strong> Арбитраж сервиса несет материальную ответственность в случае ошибки в разрешении спора между участниками, поэтому безопасная сделка в интернете с нами комфортнее, чем с кем-либо. Защита интересов предоставляется обеим сторонам: продавцу и покупателю, фрилансеру и заказчику. Гарант онлайн-сделок Linker-grand — ваш щит от нечестных продавцов и покупателей, нерадивых исполнителей, необязательных заказчиков и прочих мошенников.
  <br><br>
  <strong>Оплата за посредничество минимальна.</strong> Еще одно преимущество — низкая комиссия, которую взимает гарант безопасных сделок Linker-grand. Это небольшая сумма, но даже она дает вам уверенность, что вас не обманут.
  <br><br>
  Гарант-сервис Linker-grand является надежным ресурсом. С нами сделка без риска в интернете — это реальность, проверенная временем. Зарегистрируйте аккаунт и начните пользоваться сервисом прямо сейчас.
</div></div>
</div>
<footer class="main-footer">
  <div class="container">
    <ul class="left">
      <li>© 2015–2018 Linker-grand</li>
      <li>Обратная связь: <a href="mailto:support@linker-grand.pro">support@linker-grand.pro</a></li>
          </ul>
    <ul class="right">
        <li><a href="http://www.pwlvl.ru/" class="icon pwlvl" rel="nofollow"></a></li>
            <li>
        <!-- webmoney attestation label#2341075A-C965-4FD0-96D7-3FC6BAEA7598 begin -->
        <a href="https://passport.webmoney.ru/asp/CertView.asp?wmid=305928582560" target="_blank" class="icon wm-c" rel="nofollow"></a>
        <!-- webmoney attestation label#2341075A-C965-4FD0-96D7-3FC6BAEA7598 end -->
      </li>
      <li>
        <!-- begin WebMoney Transfer : accept label -->
        <a href="http://www.megastock.ru/" target="_blank" class="icon wm-m" rel="nofollow"></a>
        <!-- end WebMoney Transfer : accept label -->
      </li>
    </ul>
  </div>
</footer>

<script type="text/javascript" src="themes/bootlance/bootstrap/js/bootstrap.min.js"></script>

</body>
</html>