<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<title>Авторизация - Linker-grand.pro - Сервис безопасных сделок в интернете.</title> 
<meta name="description" content="Linker-grand.pro" />

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="generator" content="Cotonti http://www.cotonti.com" />
<link rel="canonical" href="https://linker-grand.pro/login.php" />
<base href="https://linker-grand.pro/" />
<link href="themes/bootlance/bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="themes/bootlance/bootstrap/css/bootstrap-responsive.css" type="text/css" rel="stylesheet" />
<link href="themes/bootlance/css/modalbox.css" type="text/css" rel="stylesheet" />
<link href="themes/bootlance/css/style.css" type="text/css" rel="stylesheet" />
<link href="themes/bootlance/css/fix.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jqModal.min.js"></script>
<script type="text/javascript" src="js/base.js"></script>
<script type="text/javascript" src="js/ajax_on.js"></script>
<script type="text/javascript" src="plugins/search/js/hl.min.js"></script>
<script type="text/javascript" src="plugins/locationselector/js/locationselector.js"></script>
<script type="text/javascript" src="themes/bootlance/js/js.js"></script><meta name="robots" content="noindex" />
<link rel="shortcut icon" href="favicon.ico" />
<link rel="apple-touch-icon" href="apple-touch-icon.png" />
</head>

<body>

	<div id="AuthModal" class="modal hide fade">
		<div class="modal-header">
			<h3 id="myModalLabel">Вход</h3>
			</div>
			<div class="modal-body">
				<form class="form-horizontal" action="login.php?a=check&amp;redirect=bG9naW4ucGhw" method="post"><div style="display:inline;margin:0;padding:0"><input type="hidden" name="x" value="10648D95" /></div>
					<div class="control-group">
						<label class="control-label" for="inputEmail">Имя или email</label>
						<div class="controls">
							<input type="text" name="rusername" id="inputEmail" />
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="inputPassword">Пароль</label>
						<div class="controls">
							<input type="password" name="rpassword" id="inputPassword" /><br/>
							<a rel="nofollow" class="link small" href="index.php?e=users&amp;m=passrecover">Восстановить пароль</a>
						</div>
					</div>
					<div class="control-group">
						<div class="controls">
							<label class="checkbox">
							<input type="checkbox" name="rremember" /> Запомнить меня
							</label><br/>
							<button type="submit" class="btn btn-primary btn-large">Вход</button>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true">Закрыть</button>
		</div>
	</div>	
	<div id="wrapper" class="container">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-inner">
				<div class="container">
						<ul class="nav pull-right">
							<li><a href="login.php" data-toggle="modal" onClick="$('#AuthModal').modal(); return false;">Вход</a></li>
							<li><a href="index.php?e=users&amp;m=register">Зарегистрироваться</a></li>
													</ul>
				</div>
			</div>
		</div>
							
		<div id="header" class="row">
			<div class="span4">
				<div class="logo"><a href="index.php" title="Linker-grand.pro - Сервис безопасных сделок в интернете. / Linker-grand.pro"><img src="themes/bootlance/img/logo.png"/></a></div>
			</div>
			<div class="span5">
				
			</div>
			<div class="span3 textright paddingtop10">
			</div>
		</div>

		<div class="navbar">
			<div class="navbar-inner">
				<ul class="nav">
					<li><a href="index.php"><b>Главная</b></a></li>
					
                <li><a href="index.php?e=sbr"><b>Мои сделки</b></a></li>
           <li> <a href="index.php?e=sbr&amp;m=add"><b>Предложить сделку</b></a></li>
				</ul>
			</div>
		</div>
		
		<div id="main" class="content">		<div class="row">
			<div class="offset3 span5 form-signin">
				<div class="mboxHD">Авторизация</div>
				<form name="login" action="login.php?a=check" method="post"><div style="display:inline;margin:0;padding:0"><input type="hidden" name="x" value="10648D95" /></div>
					<table class="main">
						<tr>
							<td class="width30">Имя или email:</td>
							<td class="width70"><input type="text" name="rusername" value=""  size="12" maxlength="100" /></td>
						</tr>
						<tr>
							<td>Пароль:</td>
							<td class="width70"><input type="password" name="rpassword" value="" size="12" maxlength="32" /></td>
						</tr>
						<tr>
							<td></td>
							<td><label class="checkbox"><input type="checkbox" name="rremember" />&nbsp; Запомнить меня</label></td>
						</tr>
						<tr>
							<td></td>
							<td>
								<button type="submit" name="rlogin" class="btn btn-large btn-primary" value="0">Вход</button>
								<br/>
								<br/>
								<a href="index.php?e=users&amp;m=passrecover">Восстановить пароль</a>
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div></div>
</div>
<footer class="main-footer">
  <div class="container">
    <ul class="left">
      <li>© 2015–2018 Linker-grand</li>
      <li>Обратная связь: <a href="mailto:support@linker-grand.pro">support@linker-grand.pro</a></li>
          </ul>
    <ul class="right">
        <li><a href="http://www.pwlvl.ru/" class="icon pwlvl" rel="nofollow"></a></li>
            <li>
        <!-- webmoney attestation label#2341075A-C965-4FD0-96D7-3FC6BAEA7598 begin -->
        <a href="https://passport.webmoney.ru/asp/CertView.asp?wmid=305928582560" target="_blank" class="icon wm-c" rel="nofollow"></a>
        <!-- webmoney attestation label#2341075A-C965-4FD0-96D7-3FC6BAEA7598 end -->
      </li>
      <li>
        <!-- begin WebMoney Transfer : accept label -->
        <a href="http://www.megastock.ru/" target="_blank" class="icon wm-m" rel="nofollow"></a>
        <!-- end WebMoney Transfer : accept label -->
      </li>
    </ul>
  </div>
</footer>

<script type="text/javascript" src="themes/bootlance/bootstrap/js/bootstrap.min.js"></script>

</body>
</html>